# Stunner Store - Ready-to-deploy package

**Theme:** Dark (black background) with gold accent
**Paystack contact email:** onigwechinazablessed776@gmail.com

## What is included
- Flask app (app.py)
- products.json (sample curated products with AliExpress links)
- Templates (Jinja2)
- Dark CSS theme (static/css/styles.css)
- README with deployment instructions

## How to upload to GitHub (quick)
1. Go to your repo: https://github.com/stunnerstore/Stunner-store
2. Click **Add file → Upload files**
3. Drag and drop the contents of this ZIP (or upload the ZIP and extract locally then upload files)
4. Commit the changes

## How to run locally
1. Install Python 3.9+
2. Create venv and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate   # or venv\\Scripts\\activate on Windows
   pip install -r requirements.txt
   ```
3. Set your Paystack secret key (do NOT commit your key to GitHub):
   ```bash
   export PAYSTACK_SECRET_KEY='sk_test_xxx'
   ```
4. Run:
   ```bash
   python app.py
   ```
5. Open http://127.0.0.1:5000

## Deploy to Render (free)
1. Create a Render account at https://render.com and connect your GitHub.
2. Create a new **Web Service** and choose your `stunner-store` repo.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app --preload -b 0.0.0.0:$PORT`
5. Add an environment variable on Render: `PAYSTACK_SECRET_KEY` with your secret key.
6. Deploy — your site will have a render.com subdomain like `stunner-store.onrender.com`.

## Notes
- Replace `YOURNUMBER` in contact.html with your WhatsApp number (in international format, no +)
- Images are hotlinked from AliExpress; for reliability, download the images and host them in `/static/media`.
- Do not commit real secret keys to the repo. Use Render's environment variable settings.

Good luck — when you've uploaded the files, tell me and I'll guide you through the Render deploy step-by-step.
