from flask import Flask, render_template, request, redirect, url_for
import json, os, requests, uuid

app = Flask(__name__)

PAYSTACK_SECRET_KEY = os.getenv('PAYSTACK_SECRET_KEY', 'sk_test_yourkeyhere')
PAYSTACK_BASE_URL = 'https://api.paystack.co'

with open('products.json', 'r', encoding='utf-8') as f:
    PRODUCTS = json.load(f)

def get_product(slug):
    for p in PRODUCTS:
        if p['slug'] == slug:
            return p
    return None

@app.route('/')
def index():
    categories = sorted({p['category'] for p in PRODUCTS})
    return render_template('index.html', products=PRODUCTS, categories=categories)

@app.route('/product/<slug>')
def product_page(slug):
    p = get_product(slug)
    if not p:
        return "Product not found", 404
    return render_template('product.html', product=p)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/order', methods=['POST'])
def order():
    data = request.form
    product_slug = data.get('product_slug')
    qty = int(data.get('qty', 1))
    name = data.get('name')
    email = data.get('email')
    phone = data.get('phone')

    product = get_product(product_slug)
    if not product:
        return "Product not found", 400

    amount_ngn = int(product['price_ngn']) * qty

    # Initialize Paystack transaction
    headers = {
        'Authorization': f'Bearer {PAYSTACK_SECRET_KEY}',
        'Content-Type': 'application/json'
    }
    payload = {
        'email': email,
        'amount': amount_ngn * 100,
        'callback_url': url_for('payment_callback', _external=True),
        'metadata': {
            'product': product['title'],
            'qty': qty,
            'buyer_name': name,
            'phone': phone
        }
    }
    resp = requests.post(f'{PAYSTACK_BASE_URL}/transaction/initialize', headers=headers, json=payload)
    if resp.status_code != 200:
        return f"Payment initialization failed: {resp.text}", 400
    res_data = resp.json()
    if not res_data.get('status'):
        return f"Payment failed: {res_data}", 400
    return redirect(res_data['data']['authorization_url'])

@app.route('/payment/callback')
def payment_callback():
    ref = request.args.get('reference')
    if not ref:
        return "No reference provided", 400
    headers = {'Authorization': f'Bearer {PAYSTACK_SECRET_KEY}'}
    verify = requests.get(f'{PAYSTACK_BASE_URL}/transaction/verify/{ref}', headers=headers)
    if verify.status_code == 200:
        result = verify.json()
        if result.get('data', {}).get('status') == 'success':
            return render_template('payment_success.html', data=result['data'])
        else:
            return render_template('payment_failed.html', data=result['data'])
    else:
        return f"Verification failed: {verify.text}", 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
